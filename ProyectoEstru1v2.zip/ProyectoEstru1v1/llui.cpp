#include "llui.h"
#include "ui_llui.h"
#include "mainwindow.h"
#include "nodeitem.h"
#include <QVariantAnimation>
#include <QEasingCurve>
#include <QTimer>
#include <QMessageBox>

LLUI::LLUI(QWidget *parent) : QMainWindow(parent), ui(new Ui::LLUI), isAnimating(false) {
    ui->setupUi(this);
    QGraphicsScene* scene = new QGraphicsScene(this);
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);
    ui->graphicsView->setSceneRect(0, 0, 800, 200);
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
}

LLUI::~LLUI() {
    delete ui;
}

void LLUI::redrawNodes() {
    QGraphicsScene* scene = ui->graphicsView->scene();
    scene->clear();

    const int nodeWidth = 120;
    const int startX = 50;
    const int y = 80;
    int totalWidth = startX * 2 + l.getItems().size() * nodeWidth;

    scene->setSceneRect(0, 0, std::max(800, totalWidth), 200);

    for (int i = 0; i < l.getItems().size(); ++i) {
        bool isLast = (i == l.getItems().size() - 1);
        NodeItem* node = new NodeItem(QString::fromStdString(l.getItems().at(i)), isLast, i == 0, isLast);
        scene->addItem(node);
        node->setPos(startX + i * nodeWidth, -100);

        QVariantAnimation* anim = new QVariantAnimation(this);
        anim->setDuration(600);
        anim->setStartValue(QPointF(startX + i * nodeWidth, -100));
        anim->setEndValue(QPointF(startX + i * nodeWidth, y));
        anim->setEasingCurve(QEasingCurve::OutBounce);

        connect(anim, &QVariantAnimation::valueChanged, [node](const QVariant &value){
            node->setPos(value.toPointF());
        });
        anim->start(QAbstractAnimation::DeleteWhenStopped);
    }
}

void LLUI::on_returnbtn_clicked() {
    (new MainWindow())->show();
    this->close();
}

void LLUI::on_insertarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) {
        l.addNode(value.toInt());
        redrawNodes();
        ui->lineEdit->clear();
    }
}

void LLUI::searchValue(int value, bool deleteAfterFind) {
    QGraphicsScene* scene = ui->graphicsView->scene();
    QList<QGraphicsItem*> items = scene->items(Qt::AscendingOrder);

    isAnimating = true;
    setButtonsEnabled(false);

    int foundIndex = -1;
    for (int i = 0; i < l.getItems().size(); ++i) {
        if (std::stoi(l.getItems().at(i)) == value) {
            foundIndex = i;
            break;
        }
    }

    int endIndex = (foundIndex != -1) ? foundIndex : items.size() - 1;

    for (int i = 0; i <= endIndex && i < items.size(); ++i) {
        NodeItem* node = dynamic_cast<NodeItem*>(items[i]);
        if (node) {
            QTimer::singleShot(600 + i * 600, [=]() {
                animateNode(node, [=](){
                    if (i == foundIndex) {
                        node->setHighlightColor(QColor(Qt::red));
                        QTimer::singleShot(800, [=](){
                            finishSearch(value, deleteAfterFind, true);
                        });
                    } else if (i == endIndex) {
                        finishSearch(value, deleteAfterFind, false);
                    }
                });
            });
        }
    }
}

void LLUI::animateNode(NodeItem* node, std::function<void()> callback) {
    QVariantAnimation* anim = new QVariantAnimation(this);
    anim->setDuration(500);
    anim->setStartValue(QColor(Qt::yellow));
    anim->setEndValue(QColor(Qt::white));

    connect(anim, &QVariantAnimation::valueChanged, [node](const QVariant &v){
        node->setHighlightColor(v.value<QColor>());
    });

    if (callback) connect(anim, &QVariantAnimation::finished, callback);
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

void LLUI::finishSearch(int value, bool deleteAfterFind, bool found) {
    if (found && deleteAfterFind) {
        l.removeNode(value);
        redrawNodes();
    }
    QMessageBox::information(this, found ? "Éxito" : "No encontrado",
                             found ? (deleteAfterFind ? "Valor eliminado" : "Valor encontrado")
                                   : "Valor no encontrado");
    isAnimating = false;
    setButtonsEnabled(true);
}

void LLUI::traverseNodes() {
    QList<QGraphicsItem*> items = ui->graphicsView->scene()->items(Qt::AscendingOrder);
    isAnimating = true;
    setButtonsEnabled(false);

    for (int i = 0; i < items.size(); ++i) {
        NodeItem* node = dynamic_cast<NodeItem*>(items[i]);
        if (node) {
            QTimer::singleShot(i * 600, [=]() {
                animateNode(node, i == items.size() - 1 ? [=](){
                    isAnimating = false;
                    setButtonsEnabled(true);
                } : std::function<void()>());
            });
        }
    }
}

void LLUI::setButtonsEnabled(bool enabled) {
    ui->insertarbtn->setEnabled(enabled);
    ui->buscarbtn->setEnabled(enabled);
    ui->recorrerbtn->setEnabled(enabled);
    ui->eliminarbtn->setEnabled(enabled);
}

void LLUI::on_buscarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) searchValue(value.toInt(), false);
}

void LLUI::on_recorrerbtn_clicked() {
    if (isAnimating) return;
    traverseNodes();
}

void LLUI::on_eliminarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) searchValue(value.toInt(), true);
}
