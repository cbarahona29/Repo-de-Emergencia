#include "linkedlist.h"
#include <iostream>
#include <string>

using std::cout;
using std::to_string;

LinkedList::LinkedList() {
    head = nullptr;
}

bool LinkedList::addNode(int val) {
    try {
        Node* newNode = new Node(val);
        if (head == nullptr) {
            head = newNode;
            return true;
        } else {
            Node* iterator = head;
            while (iterator->next != nullptr) {
                iterator = iterator->next;
            }
            iterator->next = newNode;
            return true;
        }
    } catch (...) {
        cout << "Error agregando nodo\n";
        return false;
    }
}

bool LinkedList::removeNode(int val) {
    if (!head) return false;

    if (head->value == val) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return true;
    }

    Node* current = head;
    while (current->next && current->next->value != val) {
        current = current->next;
    }

    if (current->next) {
        Node* temp = current->next;
        current->next = current->next->next;
        delete temp;
        return true;
    }
    return false;
}

string LinkedList::printList() {
    string list = "";
    Node* iterator = head;
    while (iterator != nullptr) {
        list += to_string(iterator->value);
        if (iterator->next != nullptr) {
            list += ",";
        }
        iterator = iterator->next;
    }
    return list;
}

vector<string> LinkedList::getItems() {
    vector<string> items;
    Node* current = head;
    while (current != nullptr) {
        items.push_back(to_string(current->value));
        current = current->next;
    }
    return items;
}
