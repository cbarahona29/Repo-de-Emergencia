#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , lluiWindow(nullptr)  // Inicializar puntero
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
    if(lluiWindow) {
        delete lluiWindow;
    }
}

void MainWindow::on_llbtn_clicked()
{
    lluiWindow = new LLUI(nullptr);
    lluiWindow->setWindowFlags(Qt::Window);
    lluiWindow->setAttribute(Qt::WA_DeleteOnClose);
    lluiWindow->show();
    this->close();
}
