#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include "node.h"
#include <string>
#include <vector>

using std::string;
using std::vector;

class DoubleLinkedList {
private:
    Node* head;
    Node* tail;
public:
    DoubleLinkedList();
    ~DoubleLinkedList();

    bool addNode(int val);
    bool addFront(int val);
    bool removeNode(int val);
    string printForward() const;
    string printBackward() const;
    vector<string> getItems() const;
    vector<string> getItemsReverse() const;
};

#endif // DOUBLYLINKEDLIST_H
