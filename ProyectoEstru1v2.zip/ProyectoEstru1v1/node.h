#ifndef NODE_H
#define NODE_H

class Node
{
public:
    Node(int newValue);

    int value;
    Node* next;
};

#endif // NODE_H
