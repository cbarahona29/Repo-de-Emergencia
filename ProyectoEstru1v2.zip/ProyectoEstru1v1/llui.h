#ifndef LLUI_H
#define LLUI_H

#include <QMainWindow>
#include <functional>
#include "linkedlist.h" // Asumiendo que tienes esta clase

QT_BEGIN_NAMESPACE
namespace Ui { class LLUI; }
QT_END_NAMESPACE

class NodeItem; // Forward declaration

class LLUI : public QMainWindow
{
    Q_OBJECT

public:
    LLUI(QWidget *parent = nullptr);
    ~LLUI();

private slots:
    void on_returnbtn_clicked();
    void on_insertarbtn_clicked();
    void on_buscarbtn_clicked();
    void on_recorrerbtn_clicked();
    void on_eliminarbtn_clicked();

private:
    Ui::LLUI *ui;
    LinkedList l;
    bool isAnimating;

    void redrawNodes();
    void searchValue(int value, bool deleteAfterFind);
    void traverseNodes();
    void setButtonsEnabled(bool enabled);
    void animateNode(NodeItem* node, std::function<void()> callback = nullptr);
    void finishSearch(int value, bool deleteAfterFind, bool found);
};

#endif // LLUI_H
