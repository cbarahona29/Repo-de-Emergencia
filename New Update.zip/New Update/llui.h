#ifndef LLUI_H
#define LLUI_H

#include <QMainWindow>
#include <functional>
#include <QResizeEvent>   // <-- importante
#include "linkedlist.h"

QT_BEGIN_NAMESPACE
namespace Ui { class LLUI; }
QT_END_NAMESPACE

class NodeItem;

class LLUI : public QMainWindow
{
    Q_OBJECT

public:
    explicit LLUI(QWidget *parent = nullptr);
    ~LLUI();

private slots:
    void on_returnbtn_clicked();
    void on_insertarbtn_clicked();
    void on_buscarbtn_clicked();
    void on_eliminarbtn_clicked();
    void on_insertarposbtn_clicked();



private:
    Ui::LLUI *ui;
    LinkedList l;
    bool isAnimating;

    void redrawNodes();
    void searchValue(int value, bool deleteAfterFind);
    void traverseNodes();
    void setButtonsEnabled(bool enabled);
    void animateNode(NodeItem* node, std::function<void()> callback = nullptr);
    void finishSearch(int value, bool deleteAfterFind, bool found);
};

#endif // LLUI_H

