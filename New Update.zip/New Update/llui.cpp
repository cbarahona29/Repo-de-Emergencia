#include "llui.h"
#include "ui_llui.h"
#include "mainwindow.h"
#include "nodeitem.h"
#include <QVariantAnimation>
#include <QEasingCurve>
#include <QTimer>
#include <QMessageBox>

LLUI::LLUI(QWidget *parent) : QMainWindow(parent), ui(new Ui::LLUI), isAnimating(false) {
    ui->setupUi(this);
    auto* scene = new QGraphicsScene(this);
    ui->graphicsView->setScene(scene);

    ui->graphicsView->setRenderHint(QPainter::Antialiasing);

    ui->graphicsView->setAlignment(Qt::AlignCenter);
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    ui->graphicsView->setResizeAnchor(QGraphicsView::AnchorViewCenter);
    ui->graphicsView->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);

    ui->graphicsView->setViewportUpdateMode(QGraphicsView::BoundingRectViewportUpdate);
    ui->graphicsView->setAlignment(Qt::AlignCenter); // evita “pegar” al (0,0)
}

LLUI::~LLUI() {
    delete ui;
}

void LLUI::redrawNodes() {
    QGraphicsScene* scene = ui->graphicsView->scene();
    scene->clear();

    const int nodeWidth = 120;
    const int startX   = 50;
    const int yFinal   = 0;
    const int count    = static_cast<int>(l.getItems().size());

    // Evita repintados intermedios (sin flicker)
    ui->graphicsView->setUpdatesEnabled(false);

    QVector<NodeItem*> nodes;
    nodes.reserve(count);

    // 1) CREA nodos en su POSICIÓN FINAL (para calcular bounds correctos)
    for (int i = 0; i < count; ++i) {
        const bool isLast = (i == count - 1);
        auto* node = new NodeItem(QString::fromStdString(l.getItems().at(i)), isLast, i == 0, isLast);
        scene->addItem(node);
        node->setPos(startX + i * nodeWidth, yFinal); // posición final temporal
        nodes.push_back(node);
    }

    // 2) Pre-encuadre: bounds finales -> sceneRect -> fitInView
    QRectF bounds = scene->itemsBoundingRect().adjusted(-20, -20, 20, 20);
    if (!bounds.isValid() || bounds.isNull())
        bounds = QRectF(-200, -100, 400, 200);

    scene->setSceneRect(bounds);
    ui->graphicsView->fitInView(bounds, Qt::KeepAspectRatio);
    ui->graphicsView->centerOn(bounds.center());

    // 3) Coloca nodos en POSICIÓN INICIAL y lanza animaciones
    QVariantAnimation* lastAnim = nullptr;
    for (int i = 0; i < nodes.size(); ++i) {
        auto* node = nodes[i];

        // posición inicial (fuera de vista) — aún con updates desactivados
        node->setPos(startX + i * nodeWidth, -100);

        auto* anim = new QVariantAnimation(this);
        anim->setDuration(600);
        anim->setStartValue(QPointF(startX + i * nodeWidth, -100));
        anim->setEndValue(QPointF(startX + i * nodeWidth, yFinal));
        anim->setEasingCurve(QEasingCurve::OutBounce);
        connect(anim, &QVariantAnimation::valueChanged, [node](const QVariant &v){
            node->setPos(v.toPointF());
        });
        anim->start(QAbstractAnimation::DeleteWhenStopped);
        lastAnim = anim;
    }
    ui->graphicsView->setUpdatesEnabled(true);
    ui->graphicsView->viewport()->update();

    if (lastAnim) {
        connect(lastAnim, &QVariantAnimation::finished, this, [this]() {
            auto* s = ui->graphicsView->scene();
            QRectF b = s->itemsBoundingRect().adjusted(-20, -20, 20, 20);
            if (b.isValid()) {
                s->setSceneRect(b);
                ui->graphicsView->fitInView(b, Qt::KeepAspectRatio);
                ui->graphicsView->centerOn(b.center());
            }
        });
    }
}

void LLUI::on_returnbtn_clicked() {
    (new MainWindow())->show();
    this->close();
}

void LLUI::on_insertarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) {
        l.addNode(value.toInt());
        redrawNodes();
        ui->lineEdit->clear();
    }
}

void LLUI::searchValue(int value, bool deleteAfterFind) {
    QGraphicsScene* scene = ui->graphicsView->scene();
    QList<QGraphicsItem*> items = scene->items(Qt::AscendingOrder);

    isAnimating = true;
    setButtonsEnabled(false);

    int foundIndex = -1;
    for (int i = 0; i < l.getItems().size(); ++i) {
        if (std::stoi(l.getItems().at(i)) == value) {
            foundIndex = i;
            break;
        }
    }

    int endIndex = (foundIndex != -1) ? foundIndex : items.size() - 1;

    for (int i = 0; i <= endIndex && i < items.size(); ++i) {
        NodeItem* node = dynamic_cast<NodeItem*>(items[i]);
        if (node) {
            QTimer::singleShot(600 + i * 600, [=]() {
                animateNode(node, [=](){
                    if (i == foundIndex) {
                        node->setHighlightColor(QColor(Qt::red));
                        QTimer::singleShot(800, [=](){
                            finishSearch(value, deleteAfterFind, true);
                        });
                    } else if (i == endIndex) {
                        finishSearch(value, deleteAfterFind, false);
                    }
                });
            });
        }
    }
}

void LLUI::animateNode(NodeItem* node, std::function<void()> callback) {
    QVariantAnimation* anim = new QVariantAnimation(this);
    anim->setDuration(500);
    anim->setStartValue(QColor(Qt::yellow));
    anim->setEndValue(QColor(Qt::white));

    connect(anim, &QVariantAnimation::valueChanged, [node](const QVariant &v){
        node->setHighlightColor(v.value<QColor>());
    });

    if (callback) connect(anim, &QVariantAnimation::finished, callback);
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

void LLUI::finishSearch(int value, bool deleteAfterFind, bool found) {
    if (found && deleteAfterFind) {
        l.removeNode(value);
        redrawNodes();
    }
    QMessageBox::information(this, found ? "Éxito" : "No encontrado",
                             found ? (deleteAfterFind ? "Valor eliminado" : "Valor encontrado")
                                   : "Valor no encontrado");
    isAnimating = false;
    setButtonsEnabled(true);
}

void LLUI::traverseNodes() {
    QList<QGraphicsItem*> items = ui->graphicsView->scene()->items(Qt::AscendingOrder);
    isAnimating = true;
    setButtonsEnabled(false);

    for (int i = 0; i < items.size(); ++i) {
        NodeItem* node = dynamic_cast<NodeItem*>(items[i]);
        if (node) {
            QTimer::singleShot(i * 600, [=]() {
                animateNode(node, i == items.size() - 1 ? [=](){
                    isAnimating = false;
                    setButtonsEnabled(true);
                } : std::function<void()>());
            });
        }
    }
}

void LLUI::setButtonsEnabled(bool enabled) {
    ui->insertarbtn->setEnabled(enabled);
    ui->buscarbtn->setEnabled(enabled);
    ui->eliminarbtn->setEnabled(enabled);
    ui->insertarposbtn->setEnabled(enabled);
}

void LLUI::on_buscarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) searchValue(value.toInt(), false);
}

void LLUI::on_insertarposbtn_clicked(){

}
void LLUI::on_eliminarbtn_clicked() {
    if (isAnimating) return;
    QString value = ui->lineEdit->text();
    if (!value.isEmpty()) searchValue(value.toInt(), true);
}

