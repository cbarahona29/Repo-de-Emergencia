#include "DoubleLinkedList.h"
#include <iostream>

DoubleLinkedList::DoubleLinkedList() : head(nullptr), tail(nullptr) {}

DoubleLinkedList::~DoubleLinkedList() {
    Node* current = head;
    while (current) {
        Node* next = current->next;
        delete current;
        current = next;
    }
}

bool DoubleLinkedList::addNode(int val) {
    try {
        Node* newNode = new Node(val);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        return true;
    } catch (...) {
        std::cerr << "Error agregando nodo\n";
        return false;
    }
}

bool DoubleLinkedList::addFront(int val) {
    try {
        Node* newNode = new Node(val);
        if (!head) {
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        return true;
    } catch (...) {
        std::cerr << "Error agregando nodo al frente\n";
        return false;
    }
}

bool DoubleLinkedList::removeNode(int val) {
    if (!head) return false;

    Node* current = head;
    while (current && current->value != val) {
        current = current->next;
    }

    if (!current) return false;  // No encontrado

    if (current->prev) {
        current->prev->next = current->next;
    } else {
        head = current->next;
    }

    if (current->next) {
        current->next->prev = current->prev;
    } else {
        tail = current->prev;
    }

    delete current;
    return true;
}

string DoubleLinkedList::printForward() const {
    string list;
    Node* current = head;
    while (current) {
        list += std::to_string(current->value);
        if (current->next) list += ",";
        current = current->next;
    }
    return list;
}

string DoubleLinkedList::printBackward() const {
    string list;
    Node* current = tail;
    while (current) {
        list += std::to_string(current->value);
        if (current->prev) list += ",";
        current = current->prev;
    }
    return list;
}

vector<string> DoubleLinkedList::getItems() const {
    vector<string> items;
    Node* current = head;
    while (current) {
        items.push_back(std::to_string(current->value));
        current = current->next;
    }
    return items;
}

vector<string> DoubleLinkedList::getItemsReverse() const {
    vector<string> items;
    Node* current = tail;
    while (current) {
        items.push_back(std::to_string(current->value));
        current = current->prev;
    }
    return items;
}
