// nodeitem.cpp
#include "nodeitem.h"

NodeItem::NodeItem(const QString& val, bool isLast, bool isHead, bool isTail, QGraphicsItem* parent)
    : QGraphicsItem(parent),
    value(val),
    isLast(isLast),
    isHead(isHead),
    isTail(isTail),
    highlightColor(Qt::white) {}

QRectF NodeItem::boundingRect() const {
    return QRectF(0, 0, 120, 80).adjusted(-2, -2, 2, 2);
}

void NodeItem::paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*) {
    painter->setBrush(highlightColor);
    painter->setPen(QPen(Qt::black, 2));
    painter->drawEllipse(0, 0, 40, 40);

    painter->setPen(Qt::black);
    painter->drawText(QRectF(0, 0, 40, 40), Qt::AlignCenter, value);

    // Flech    a
    QLineF line(40, 20, 100, 20);
    painter->drawLine(line);
    QPointF arrowP1 = line.p2() - QPointF(10, 5);
    QPointF arrowP2 = line.p2() - QPointF(10, -5);
    QPolygonF arrowHead;
    arrowHead << line.p2() << arrowP1 << arrowP2;
    painter->setBrush(Qt::black);
    painter->drawPolygon(arrowHead);

    if (isLast)
        painter->drawText(QPointF(100, 15), "null");

    painter->setPen(Qt::darkBlue);
    QFont font = painter->font();
    font.setBold(true);
    painter->setFont(font);

    const bool isSingleNode = isHead && isLast;

    if (isHead) {
        painter->drawText(QRectF(0, 45, 40, 20), Qt::AlignCenter, "HEAD");
    }

    if (isTail && !isSingleNode) {
        painter->drawText(QRectF(0, 45, 40, 20), Qt::AlignCenter, "TAIL");
    }
}

void NodeItem::setIsLast(bool last) { isLast = last; update(); }
void NodeItem::setIsHead(bool head) { isHead = head; update(); }
void NodeItem::setIsTail(bool tail) { isTail = tail; update(); }

void NodeItem::setHighlightColor(const QColor& color) {
    highlightColor = color;
    update();
}
