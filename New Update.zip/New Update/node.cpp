#include "node.h"

Node::Node(int newValue) {
    this->value = newValue;
    this->next = nullptr;
    this->prev = nullptr;
}
