// nodeitem.h
#ifndef NODEITEM_H
#define NODEITEM_H

#include <QGraphicsItem>
#include <QPainter>

class NodeItem : public QGraphicsItem
{
public:
    NodeItem(const QString& val, bool isLast, bool isHead, bool isTail, QGraphicsItem* parent = nullptr);

    QRectF boundingRect() const override;
    void paint(QPainter* painter, const QStyleOptionGraphicsItem*, QWidget*) override;

    void setIsLast(bool last);
    void setIsHead(bool head);
    void setIsTail(bool tail);

    void setHighlightColor(const QColor& color); // Para animaciones de recorrido

private:
    QString value;
    bool isLast;
    bool isHead;
    bool isTail;
    QColor highlightColor; // color temporal
};

#endif // NODEITEM_H
