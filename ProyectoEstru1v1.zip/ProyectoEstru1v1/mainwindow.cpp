#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , lluiWindow(nullptr)  // Inicializar puntero
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
    if(lluiWindow) {
        delete lluiWindow;
    }
}

void MainWindow::on_llbtn_clicked()
{
    // Crear la nueva ventana sin parent (nullptr) para que sea independiente
    lluiWindow = new LLUI(nullptr);

    // Hacer que se comporte como una ventana independiente
    lluiWindow->setWindowFlags(Qt::Window);
    lluiWindow->setAttribute(Qt::WA_DeleteOnClose); // Se elimina automáticamente al cerrar

    // Mostrar la nueva ventana
    lluiWindow->show();

    // Cerrar la ventana actual
    this->close();
}
