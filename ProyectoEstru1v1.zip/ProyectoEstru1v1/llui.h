#ifndef LLUI_H
#define LLUI_H

#include <QWidget>

namespace Ui {
class LLUI;
}

class LLUI : public QWidget
{
    Q_OBJECT

public:
    explicit LLUI(QWidget *parent = nullptr);
    ~LLUI();

private:
    Ui::LLUI *ui;
};

#endif // LLUI_H
