#ifndef NODEGRAPHIC_H
#define NODEGRAPHIC_H

class NodeGraphic
{
public:
    NodeGraphic();
};

#endif // NODEGRAPHIC_H
