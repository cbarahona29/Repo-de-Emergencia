#include "llui.h"
#include "ui_llui.h"

LLUI::LLUI(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::LLUI)
{
    ui->setupUi(this);

    // Configurar como ventana independiente
    setWindowFlags(Qt::Window);
    setWindowTitle("Linked List"); // Título de la ventana
}

LLUI::~LLUI()
{
    delete ui;
}
