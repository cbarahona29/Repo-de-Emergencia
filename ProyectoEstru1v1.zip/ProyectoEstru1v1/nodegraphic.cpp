#include "nodegraphic.h"


NodeGraphic::NodeGraphic()
{

}
